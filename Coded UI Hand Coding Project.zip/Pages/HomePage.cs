﻿using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class HomePage
    {
        private BrowserWindow browser;

        public HomePage(BrowserWindow browser){
            this.browser = browser;
        }

        //Sample Web Elements
        private HtmlButton searchBtn()
        {
            //Search Btn
            HtmlButton searchBtn = new HtmlButton(browser);
            searchBtn.TechnologyName = "Web";
            searchBtn.SearchProperties.Add(HtmlButton.PropertyNames.Class, "lsb");
            searchBtn.SearchProperties.Add(HtmlButton.PropertyNames.Name, "btnG");
            
            //If required user can use DrawHighLight to draw blue highlight around control for diagnostics
           // searchBtn.DrawHighlight();
            return searchBtn;
        }

        private HtmlEdit searchTextBox()
        {
            HtmlEdit searchTextBox = new HtmlEdit(browser);
            searchTextBox.TechnologyName = "Web";
            searchTextBox.SearchProperties.Add(HtmlEdit.PropertyNames.ControlType, "Edit");
            searchTextBox.SearchProperties.Add(HtmlEdit.PropertyNames.Id, "lst-ib");

            //If required user can use DrawHighLight to draw blue highlight around control for diagnostics
            // searchTextBox.DrawHighlight();
            return searchTextBox;
        }

        public void SearchGoogle(string searchText)
        {
            searchTextBox().Text = searchText;
            Mouse.Click(searchBtn());
        }
    }


}
